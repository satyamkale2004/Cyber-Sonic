<?php
include '../db_config.php';
?>
<div class="section">
    <h2>Manage Train Ticket Booking</h2>
    
    <!-- Form to Add New Record -->
    <form method="POST" action="../actions.php">
        <input type="number" name="user_id" placeholder="User ID" required>
        <input type="text" name="full_name" placeholder="Full Name" required>
        <input type="text" name="contact_details" placeholder="Contact Details" required>
        <input type="text" name="departure_location" placeholder="Departure Location" required>
        <input type="text" name="destination" placeholder="Destination" required>
        <input type="date" name="travelling_date" placeholder="Travelling Date" required>
        <input type="time" name="travelling_time" placeholder="Travelling Time" required>
        <button type="submit" name="addTrainBooking">Add Booking</button>
    </form>

    <!-- Search Bar -->
    <input type="text" id="searchBarTrainBooking" placeholder="Search bookings..." onkeyup="searchRecords('searchBarTrainBooking', 'trainBookingTable')">

    <!-- Table to Display Records -->
    <table id="trainBookingTable">
        <thead>
            <tr>
                <th>ID</th>
                <th>User ID</th>
                <th>Full Name</th>
                <th>Contact</th>
                <th>Departure Location</th>
                <th>Destination</th>
                <th>Travelling Date</th>
                <th>Travelling Time</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $sql = "SELECT * FROM train_ticket_booking";
            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    echo "<tr>
                            <td>{$row['id']}</td>
                            <td>{$row['user_id']}</td>
                            <td>{$row['full_name']}</td>
                            <td>{$row['contact_details']}</td>
                            <td>{$row['departure_location']}</td>
                            <td>{$row['destination']}</td>
                            <td>{$row['travelling_date']}</td>
                            <td>{$row['travelling_time']}</td>
                            <td>
                                <button onclick=\"editRecord({$row['id']}, 'train_ticket_booking')\">Edit</button>
                                <button onclick=\"deleteRecord({$row['id']}, 'train_ticket_booking')\">Delete</button>
                            </td>
                          </tr>";
                }
            }
            ?>
        </tbody>
    </table>
</div>