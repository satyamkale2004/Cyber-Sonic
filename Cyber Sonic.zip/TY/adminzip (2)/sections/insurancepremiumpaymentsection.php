<?php
include '../db_config.php';
?>
<div class="section">
    <h2>Manage Insurance Premium Payments</h2>
    
    <!-- Form to Add New Record -->
    <form method="POST" action="../actions.php">
        <input type="number" name="user_id" placeholder="User ID" required>
        <input type="text" name="full_name" placeholder="Full Name" required>
        <input type="text" name="policy_number" placeholder="Policy Number" required>
        <input type="email" name="email_id" placeholder="Email ID" required>
        <input type="text" name="id_proof" placeholder="ID Proof" required>
        <input type="date" name="birth_date" placeholder="Date of Birth" required>
        <button type="submit" name="addInsurancePayment">Add Payment</button>
    </form>

    <!-- Search Bar -->
    <input type="text" id="searchBarInsurancePayments" placeholder="Search payments..." onkeyup="searchRecords('searchBarInsurancePayments', 'insurancePaymentTable')">

    <!-- Table to Display Records -->
    <table id="insurancePaymentTable">
        <thead>
            <tr>
                <th>ID</th>
                <th>User ID</th>
                <th>Full Name</th>
                <th>Policy Number</th>
                <th>Email</th>
                <th>ID Proof</th>
                <th>Date of Birth</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $sql = "SELECT * FROM insurance_premium_payment";
            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    echo "<tr>
                            <td>{$row['id']}</td>
                            <td>{$row['user_id']}</td>
                            <td>{$row['full_name']}</td>
                            <td>{$row['policy_number']}</td>
                            <td>{$row['email_id']}</td>
                            <td>{$row['id_proof']}</td>
                            <td>{$row['birth_date']}</td>
                            <td>
                                <button onclick=\"editRecord({$row['id']}, 'insurance_premium_payment')\">Edit</button>
                                <button onclick=\"deleteRecord({$row['id']}, 'insurance_premium_payment')\">Delete</button>
                            </td>
                          </tr>";
                }
            }
            ?>
        </tbody>
    </table>
</div>