<?php
include '../db_config.php';
?>
<div class="section">
    <h2>Manage Health Insurance Premiums</h2>
    
    <!-- Form to Add New Record -->
    <form method="POST" action="../actions.php">
        <input type="number" name="user_id" placeholder="User ID" required>
        <input type="text" name="policy_id" placeholder="Policy ID" required>
        <input type="date" name="date_of_birth" placeholder="Date of Birth" required>
        <button type="submit" name="addHealthInsurance">Add Policy</button>
    </form>

    <!-- Search Bar -->
    <input type="text" id="searchBarHealthInsurance" placeholder="Search policies..." onkeyup="searchRecords('searchBarHealthInsurance', 'healthInsuranceTable')">

    <!-- Table to Display Records -->
    <table id="healthInsuranceTable">
        <thead>
            <tr>
                <th>ID</th>
                <th>User ID</th>
                <th>Policy ID</th>
                <th>Date of Birth</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $sql = "SELECT * FROM health_insurance_premium";
            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    echo "<tr>
                            <td>{$row['id']}</td>
                            <td>{$row['user_id']}</td>
                            <td>{$row['policy_id']}</td>
                            <td>{$row['date_of_birth']}</td>
                            <td>
                                <button onclick=\"editRecord({$row['id']}, 'health_insurance_premium')\">Edit</button>
                                <button onclick=\"deleteRecord({$row['id']}, 'health_insurance_premium')\">Delete</button>
                            </td>
                          </tr>";
                }
            }
            ?>
        </tbody>
    </table>
</div>