<?php
include '../db_config.php';
?>
<div class="section">
    <h2>Manage User Profiles</h2>
    
    <!-- Form to Add New Record -->
    <form method="POST" action="../actions.php">
        <input type="number" name="user_id" placeholder="User ID" required>
        <input type="text" name="full_name" placeholder="Full Name">
        <input type="text" name="phone" placeholder="Phone">
        <input type="text" name="address" placeholder="Address">
        <button type="submit" name="addUserProfile">Add Profile</button>
    </form>

    <!-- Search Bar -->
    <input type="text" id="searchBarUserProfiles" placeholder="Search profiles..." onkeyup="searchRecords('searchBarUserProfiles', 'userProfilesTable')">

    <!-- Table to Display Records -->
    <table id="userProfilesTable">
        <thead>
            <tr>
                <th>ID</th>
                <th>User ID</th>
                <th>Full Name</th>
                <th>Phone</th>
                <th>Address</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $sql = "SELECT * FROM user_profiles";
            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    echo "<tr>
                            <td>{$row['id']}</td>
                            <td>{$row['user_id']}</td>
                            <td>{$row['full_name']}</td>
                            <td>{$row['phone']}</td>
                            <td>{$row['address']}</td>
                            <td>
                                <button onclick=\"editRecord({$row['id']}, 'user_profiles')\">Edit</button>
                                <button onclick=\"deleteRecord({$row['id']}, 'user_profiles')\">Delete</button>
                            </td>
                          </tr>";
                }
            }
            ?>
        </tbody>
    </table>
</div>