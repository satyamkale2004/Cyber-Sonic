<?php
include '../db_config.php';
?>
<div class="section">
    <h2>Manage Exam Form Filling</h2>
    
    <!-- Form to Add New Record -->
    <form method="POST" action="../actions.php">
        <input type="number" name="user_id" placeholder="User ID" required>
        <input type="text" name="student_name" placeholder="Student Name" required>
        <input type="text" name="father_name" placeholder="Father's Name" required>
        <input type="text" name="mother_name" placeholder="Mother's Name" required>
        <input type="text" name="address" placeholder="Address" required>
        <input type="text" name="phone" placeholder="Phone" required>
        <input type="email" name="email" placeholder="Email" required>
        <input type="text" name="college" placeholder="College Name" required>
        <button type="submit" name="addExamForm">Add Exam Form</button>
    </form>

    <!-- Search Bar -->
    <input type="text" id="searchBarExamForms" placeholder="Search exam forms..." onkeyup="searchRecords('searchBarExamForms', 'examFormsTable')">

    <!-- Table to Display Records -->
    <table id="examFormsTable">
        <thead>
            <tr>
                <th>ID</th>
                <th>User ID</th>
                <th>Student Name</th>
                <th>Father's Name</th>
                <th>Mother's Name</th>
                <th>Address</th>
                <th>Phone</th>
                <th>Email</th>
                <th>College</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $sql = "SELECT * FROM exam_form_filling";
            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    echo "<tr>
                            <td>{$row['id']}</td>
                            <td>{$row['user_id']}</td>
                            <td>{$row['student_name']}</td>
                            <td>{$row['father_name']}</td>
                            <td>{$row['mother_name']}</td>
                            <td>{$row['address']}</td>
                            <td>{$row['phone']}</td>
                            <td>{$row['email']}</td>
                            <td>{$row['college']}</td>
                            <td>
                                <button onclick=\"editRecord({$row['id']}, 'exam_form_filling')\">Edit</button>
                                <button onclick=\"deleteRecord({$row['id']}, 'exam_form_filling')\">Delete</button>
                            </td>
                          </tr>";
                }
            }
            ?>
        </tbody>
    </table>
</div>