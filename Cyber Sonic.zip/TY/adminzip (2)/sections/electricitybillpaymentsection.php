<?php
include '../db_config.php';
?>
<div class="section">
    <h2>Manage Electricity Bill Payments</h2>
    
    <!-- Form to Add New Record -->
    <form method="POST" action="../actions.php">
        <input type="number" name="user_id" placeholder="User ID" required>
        <input type="text" name="consumer_id" placeholder="Consumer ID" required>
        <input type="number" name="sub_division_code" placeholder="Sub Division Code" required>
        <button type="submit" name="addElectricityBill">Add Bill</button>
    </form>

    <!-- Search Bar -->
    <input type="text" id="searchBarElectricityBill" placeholder="Search bills..." onkeyup="searchRecords('searchBarElectricityBill', 'electricityBillTable')">

    <!-- Table to Display Records -->
    <table id="electricityBillTable">
        <thead>
            <tr>
                <th>ID</th>
                <th>User ID</th>
                <th>Consumer ID</th>
                <th>Sub Division Code</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $sql = "SELECT * FROM electricity_bill_payment";
            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    echo "<tr>
                            <td>{$row['id']}</td>
                            <td>{$row['user_id']}</td>
                            <td>{$row['consumer_id']}</td>
                            <td>{$row['sub_division_code']}</td>
                            <td>
                                <button onclick=\"editRecord({$row['id']}, 'electricity_bill_payment')\">Edit</button>
                                <button onclick=\"deleteRecord({$row['id']}, 'electricity_bill_payment')\">Delete</button>
                            </td>
                          </tr>";
                }
            }
            ?>
        </tbody>
    </table>
</div>