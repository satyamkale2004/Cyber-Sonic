<?php
include '../db_config.php';
?>
<div class="section">
    <h2>Manage Flight Ticket Booking</h2>

    <!-- Form to Add New Record -->
    <form method="POST" action="../actions.php">
        <input type="number" name="user_id" placeholder="User ID" required>
        <input type="text" name="full_name" placeholder="Full Name" required>
        <input type="text" name="contact" placeholder="Contact" required>
        <input type="date" name="date_of_birth" placeholder="Date of Birth" required>
        <input type="text" name="flight_details" placeholder="Flight Details" required>
        <input type="date" name="travelling_date" placeholder="Travelling Date" required>
        <input type="time" name="travelling_time" placeholder="Travelling Time" required>
        <button type="submit" name="addFlightBooking">Add Booking</button>
    </form>

    <!-- Search Bar -->
    <input type="text" id="searchBarFlightBooking" placeholder="Search bookings..." onkeyup="searchRecords('searchBarFlightBooking', 'flightBookingTable')">

    <!-- Table to Display Records -->
    <table id="flightBookingTable">
        <thead>
            <tr>
                <th>ID</th>
                <th>User ID</th>
                <th>Full Name</th>
                <th>Contact</th>
                <th>Date of Birth</th>
                <th>Flight Details</th>
                <th>Travelling Date</th>
                <th>Travelling Time</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $sql = "SELECT * FROM flight_ticket_booking";
            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    echo "<tr>
                            <td>{$row['id']}</td>
                            <td>{$row['user_id']}</td>
                            <td>{$row['full_name']}</td>
                            <td>{$row['contact']}</td>
                            <td>{$row['date_of_birth']}</td>
                            <td>{$row['flight_details']}</td>
                            <td>{$row['travelling_date']}</td>
                            <td>{$row['travelling_time']}</td>
                            <td>
                                <button onclick=\"editRecord({$row['id']}, 'flight_ticket_booking')\">Edit</button>
                                <button onclick=\"deleteRecord({$row['id']}, 'flight_ticket_booking')\">Delete</button>
                            </td>
                          </tr>";
                }
            }
            ?>
        </tbody>
    </table>
</div>