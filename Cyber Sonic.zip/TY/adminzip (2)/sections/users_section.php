<?php
include '../db_config.php'; // Adjust path for sections folder
?>
<div class="section">
    <h2>Manage Users</h2>
    
    <!-- Form to Add New Record -->
    <form method="POST" action="../actions.php">
        <input type="email" name="email" placeholder="Email" required>
        <input type="password" name="password" placeholder="Password" required>
        <button type="submit" name="addUser">Add User</button>
    </form>

    <!-- Search Bar -->
    <input type="text" id="searchBarUsers" placeholder="Search users..." onkeyup="searchRecords('searchBarUsers', 'usersTable')">

    <!-- Table to Display Records -->
    <table id="usersTable">
        <thead>
            <tr>
                <th>ID</th>
                <th>Email</th>
                <th>Password</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $sql = "SELECT * FROM users";
            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    echo "<tr>
                            <td>{$row['id']}</td>
                            <td>{$row['email']}</td>
                            <td>********</td>
                            <td>
                                <button onclick=\"editRecord({$row['id']}, 'users')\">Edit</button>
                                <button onclick=\"deleteRecord({$row['id']}, 'users')\">Delete</button>
                            </td>
                          </tr>";
                }
            }
            ?>
        </tbody>
    </table>
</div>