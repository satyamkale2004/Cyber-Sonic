<?php
include '../db_config.php';
?>
<div class="section">
    <h2>Manage Event Ticket Bookings</h2>
    
    <!-- Form to Add New Record -->
    <form method="POST" action="../actions.php">
        <input type="number" name="user_id" placeholder="User ID" required>
        <input type="text" name="full_name" placeholder="Full Name" required>
        <input type="text" name="event_name" placeholder="Event Name" required>
        <input type="email" name="email_confirmation" placeholder="Email Confirmation" required>
        <input type="date" name="event_date" placeholder="Event Date" required>
        <input type="time" name="event_time" placeholder="Event Time" required>
        <button type="submit" name="addEventTicket">Add Ticket</button>
    </form>

    <!-- Search Bar -->
    <input type="text" id="searchBarEventTickets" placeholder="Search tickets..." onkeyup="searchRecords('searchBarEventTickets', 'eventTicketTable')">

    <!-- Table to Display Records -->
    <table id="eventTicketTable">
        <thead>
            <tr>
                <th>ID</th>
                <th>User ID</th>
                <th>Full Name</th>
                <th>Event Name</th>
                <th>Email Confirmation</th>
                <th>Event Date</th>
                <th>Event Time</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $sql = "SELECT * FROM event_ticket_booking";
            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    echo "<tr>
                            <td>{$row['id']}</td>
                            <td>{$row['user_id']}</td>
                            <td>{$row['full_name']}</td>
                            <td>{$row['event_name']}</td>
                            <td>{$row['email_confirmation']}</td>
                            <td>{$row['event_date']}</td>
                            <td>{$row['event_time']}</td>
                            <td>
                                <button onclick=\"editRecord({$row['id']}, 'event_ticket_booking')\">Edit</button>
                                <button onclick=\"deleteRecord({$row['id']}, 'event_ticket_booking')\">Delete</button>
                            </td>
                          </tr>";
                }
            }
            ?>
        </tbody>
    </table>
</div>
