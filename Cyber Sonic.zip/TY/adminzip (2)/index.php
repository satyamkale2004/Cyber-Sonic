<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CYBER SONIC ADMIN PANEL</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <h1>CYBER SONIC ADMIN PANEL</h1>
        <!-- Navigation Buttons -->
        <nav class="tabs">
            <button class="tab-btn" onclick="loadSection('users_section.php')">Users</button>
            <button class="tab-btn" onclick="loadSection('userprofilessection.php')">User Profiles</button>
            <button class="tab-btn" onclick="loadSection('examformfillingsection.php')">Exam Form Filling</button>
            <button class="tab-btn" onclick="loadSection('abcidcreationsection.php')">ABC ID Creation</button>
            <button class="tab-btn" onclick="loadSection('flightticketbookingsection.php')">Flight Ticket Booking</button>
            <button class="tab-btn" onclick="loadSection('trainticketbookingsection.php')">Train Ticket Booking</button>
            <button class="tab-btn" onclick="loadSection('insurancepremiumpaymentsection.php')">Insurance Premium</button>
            <button class="tab-btn" onclick="loadSection('eventticketbookingsection.php')">Event Ticket Booking</button>
            <button class="tab-btn" onclick="loadSection('electricitybillpaymentsection.php')">Electricity Bills</button>
            <button class="tab-btn" onclick="loadSection('healthinsurancepremiumsection.php')">Health Insurance</button>
        </nav>

        <!-- Content Area -->
        <div id="contentArea">
            <p>Click a section button above to manage records dynamically.</p>
        </div>
    </div>
    <script src="script.js"></script>
</body>
</html>